#include <stdio.h>

int main() {
	FILE *out=fopen("html_commands.txt","w");
	fputs("Basic HTML Commands: \n<html>\n<head>\n<title></title>\n</head>\n<h1></h1>\n<h2></h2>\n<h3></h3>\n<h4></h4>\n<h5></h5>\n<h6></h6>\n<p></p>\n<br>\n<pre></pre>\n<b></b>\n<i></i>\n<strong></strong>\n<em></em>\n",out);
	fclose(out);
	
	return 0;
}
